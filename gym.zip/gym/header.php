<nav class="navbar navbar-inverse">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="#"><b>Focus Fitness</b></a>
        </div>
        <ul class="nav navbar-nav">
            <li ><a href="index.php" >Home</a></li>
            <li><a href="registation.php">Registation</a></li>
            <li ><a href="payment.php" >Payment</a></li>
            <li ><a href="plan.php" >Plan</a></li>

            <li><a href="report.php">Report</a></li>
            <li><a href="member.php">View Members</a></li>
        </ul>
        <ul class="nav navbar-nav navbar-right">

            <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
        </ul>
    </div>
</nav